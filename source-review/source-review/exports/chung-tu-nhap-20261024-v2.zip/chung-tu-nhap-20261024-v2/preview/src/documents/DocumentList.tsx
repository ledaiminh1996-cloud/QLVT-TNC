import { useEffect, useRef, useState } from "react";
import {
  Plus,
  RefreshCw,
  Pencil,
  History,
  Printer,
  Upload,
  Download,
  Eye,
} from "lucide-react";
import { documentKinds, editableDraft } from "../../shared/documents";
import type {
  DocumentKind,
  DocumentRecord,
  DocumentSummary,
} from "../../shared/documents";
import type { DocumentClient, DocumentPage } from "./documentClient";
import type { CatalogClient, Session } from "../api/catalogClient";
import { accessMessage } from "../api/catalogClient";
import { docButton, docInput } from "./CatalogPicker";
import { DocumentEditor, money } from "./DocumentEditor";
import { DocumentHistory } from "./DocumentHistory";
import { DocumentWorkflows } from "./DocumentWorkflows";
import { DocumentBulkImport } from "./DocumentBulkImport";

import { StatusBadge } from "../components/StatusBadge";
import { MenuIcon } from "../components/MenuIcon";

function exportJSON(row: DocumentRecord) {
  const link = document.createElement("a"),
    url = URL.createObjectURL(
      new Blob([JSON.stringify(row, null, 2)], { type: "application/json" }),
    );
  link.href = url;
  link.download = row.code.replaceAll("/", "-") + ".json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function DocumentList({
  kind,
  api,
  documents,
  user,
  createToken,
}: {
  kind: DocumentKind;
  api: CatalogClient;
  documents: DocumentClient;
  user: NonNullable<Session["user"]>;
  createToken: number;
}) {
  const [query, setQuery] = useState(""),
    [search, setSearch] = useState(""),
    [status, setStatus] = useState(""),
    [from, setFrom] = useState(""),
    [to, setTo] = useState(""),
    [page, setPage] = useState(1),
    [revision, setRevision] = useState(0),
    [result, setResult] = useState<DocumentPage<DocumentSummary>>(),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState(""),
    [form, setForm] = useState<{ record?: DocumentRecord }>(),
    [history, setHistory] = useState<DocumentRecord>(),
    [bulk, setBulk] = useState(false),
    [action, setAction] = useState<{ row: DocumentRecord; kind: string }>(),
    [reason, setReason] = useState("");
  const writable = ["admin", "accountant", "warehouse"].includes(user.role),
    admin = ["admin", "accountant"].includes(user.role),
    request = useRef<AbortController | undefined>(undefined),
    actionLock = useRef(false);
  useEffect(() => {
    if (createToken > 0 && writable) setForm({});
  }, [createToken, writable]);
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearch(query);
      setPage(1);
    }, 250);
    return () => clearTimeout(timer);
  }, [query]);
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setResult(undefined);
    setError("");
    documents
      .list({
        kind,
        page,
        q: search,
        status,
        from,
        to,
        signal: controller.signal,
      })
      .then((value) => {
        if (!controller.signal.aborted) setResult(value);
      })
      .catch((e) => {
        if (!controller.signal.aborted) setError(accessMessage(e));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [documents, kind, page, search, status, from, to, revision]);
  useEffect(() => () => request.current?.abort(), []);
  async function open(
    row: DocumentSummary,
    mode: "edit" | "history" | "print" | "export" | "actions",
  ) {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setBusy(true);
    setError("");
    try {
      const detail = await documents.get(row.id, controller.signal);
      if (controller.signal.aborted) return;
      if (mode === "history") setHistory(detail);
      else if (mode === "print") {
        const { printDraft } = await import("./DocumentPrint");
        if (!controller.signal.aborted) printDraft(detail);
      } else if (mode === "export") exportJSON(detail);
      else if (mode === "actions") {
        setReason("");
        setAction({ row: detail, kind: "" });
      } else setForm({ record: detail });
    } catch (e) {
      if (!controller.signal.aborted) setError(accessMessage(e));
    } finally {
      if (!controller.signal.aborted) setBusy(false);
    }
  }
  const statuses = {
    draft: "Nháp",
    pending: "Chờ duyệt",
    approved: "Đã duyệt",
    returned: "Trả về",
    rejected: "Từ chối",
    cancelled: "Đã hủy",
  };
  return (
    <section className="catalog-page space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white p-4">
        <h2 className="flex items-center gap-2 font-bold">
          <MenuIcon
            menuId={documentKinds[kind].menu}
            className="text-blue-600"
          />
          {documentKinds[kind].label}
        </h2>
        <div className="flex flex-wrap gap-2">
          {writable && kind === "issue" && (
            <button className={docButton} onClick={() => setBulk(true)}>
              <Upload size={14} />
              Nhập nhiều phiếu PX
            </button>
          )}
          <button
            className={docButton}
            aria-label="Tải lại chứng từ"
            disabled={loading || busy}
            onClick={() => setRevision((n) => n + 1)}
          >
            <RefreshCw size={14} />
          </button>
          {writable && (
            <button
              className={docButton + " !bg-blue-600 !text-white"}
              onClick={() => setForm({})}
            >
              <Plus size={14} />
              Lập phiếu
            </button>
          )}
        </div>
      </div>
      <p className="rounded-lg border border-blue-100 bg-blue-50 px-3 py-2 text-xs text-blue-700">
        Bước chuẩn bị chứng từ: lưu nháp và duyệt đề xuất. Chưa bật ghi sổ, cập
        nhật tồn kho hoặc nhận đắp.
      </p>
      <div className="grid gap-2 sm:grid-cols-[minmax(180px,1fr)_180px_160px_160px]">
        <input
          aria-label="Tìm chứng từ"
          placeholder="Tìm số phiếu, vật tư, đối tác…"
          className={docInput}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          aria-label="Trạng thái chứng từ"
          className={docInput}
          value={status}
          onChange={(e) => {
            setStatus(e.target.value);
            setPage(1);
          }}
        >
          <option value="">Tất cả trạng thái</option>
          {Object.entries(statuses)
            .filter(
              ([key]) =>
                kind === "proposal" || ["draft", "cancelled"].includes(key),
            )
            .map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
        </select>
        <input
          aria-label="Từ ngày"
          title="Từ ngày"
          type="date"
          className={docInput}
          value={from}
          onChange={(e) => {
            setFrom(e.target.value);
            setPage(1);
          }}
        />
        <input
          aria-label="Đến ngày"
          title="Đến ngày"
          type="date"
          className={docInput}
          value={to}
          onChange={(e) => {
            setTo(e.target.value);
            setPage(1);
          }}
        />
      </div>
      {notice && (
        <p role="status" className="text-xs text-emerald-700">
          {notice}
        </p>
      )}
      {error && (
        <p
          role="alert"
          className="rounded-lg bg-red-50 p-3 text-xs text-red-700"
        >
          {error}{" "}
          <button
            className={docButton}
            onClick={() => setRevision((n) => n + 1)}
          >
            Thử lại
          </button>
        </p>
      )}
      {loading ? (
        <p role="status" className="p-5 text-sm">
          Đang tải chứng từ…
        </p>
      ) : (
        result && (
          <>
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
              <table className="catalog-table w-full min-w-[1126px] table-fixed text-left">
                <colgroup>
                  <col style={{ width: 164 }} />
                  <col style={{ width: 140 }} />
                  <col style={{ width: 170 }} />
                  <col style={{ width: 170 }} />
                  <col style={{ width: 64 }} />
                  <col style={{ width: 124 }} />
                  <col style={{ width: 110 }} />
                  <col style={{ width: 184 }} />
                </colgroup>
                <thead className="bg-slate-50 text-slate-600">
                  <tr>
                    <th>Số phiếu</th>
                    <th>Ngày giờ</th>
                    <th>Kho</th>
                    <th>Đối tác / người nhận</th>
                    <th className="text-right">Dòng</th>
                    <th className="text-right">Sau VAT (đ)</th>
                    <th className="text-center">Trạng thái</th>
                    <th className="text-center">Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  {result.data.map((row) => (
                    <tr
                      key={row.id}
                      className="border-t border-slate-100 hover:bg-slate-50/70"
                    >
                      <td className="font-mono font-bold text-amber-700">
                        {row.code}
                      </td>
                      <td className="tabular-nums">
                        {row.business_at.replace("T", " ")}
                      </td>
                      <td title={row.warehouse_label}>
                        {row.warehouse_label || "—"}
                      </td>
                      <td title={row.partner_label}>
                        {row.partner_label || "—"}
                      </td>
                      <td className="text-right tabular-nums">
                        {row.line_count}
                      </td>
                      <td
                        title={
                          row.totals.gross === null
                            ? "Giá vốn chưa xác định khi chưa ghi sổ"
                            : undefined
                        }
                        className="text-right font-sans tabular-nums"
                      >
                        {row.totals.gross === null
                          ? "—"
                          : new Intl.NumberFormat("vi-VN").format(
                              row.totals.gross,
                            )}
                      </td>
                      <td className="catalog-cell-center">
                        <StatusBadge
                          value={row.status}
                          label={statuses[row.status]}
                        />
                      </td>
                      <td className="catalog-actions-cell">
                        <div className="catalog-actions">
                          <button
                            className={docButton + " !px-1.5"}
                            disabled={busy}
                            aria-label={"Mở " + row.code}
                            onClick={() => {
                              void open(row, "edit");
                            }}
                          >
                            {writable && editableDraft(row.status) ? (
                              <Pencil size={13} />
                            ) : (
                              <Eye size={13} />
                            )}
                          </button>
                          <button
                            className={docButton + " !px-1.5"}
                            disabled={busy}
                            aria-label={"Lịch sử " + row.code}
                            onClick={() => {
                              void open(row, "history");
                            }}
                          >
                            <History size={13} />
                          </button>
                          <button
                            className={docButton + " !px-1.5"}
                            disabled={busy}
                            aria-label={"In nháp " + row.code}
                            onClick={() => {
                              void open(row, "print");
                            }}
                          >
                            <Printer size={13} />
                          </button>
                          <button
                            className={docButton + " !px-1.5"}
                            disabled={busy}
                            aria-label={"Xuất JSON " + row.code}
                            onClick={() => {
                              void open(row, "export");
                            }}
                          >
                            <Download size={13} />
                          </button>
                          {writable && row.status !== "cancelled" && (
                            <button
                              className={docButton + " !px-2"}
                              disabled={busy}
                              aria-label={"Xử lý " + row.code}
                              onClick={() => {
                                void open(row, "actions");
                              }}
                            >
                              ⋯
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {!result.data.length && (
                    <tr>
                      <td colSpan={8} className="text-center text-slate-500">
                        Chưa có chứng từ phù hợp.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between gap-3 text-xs text-slate-600">
              <span className="tabular-nums">
                Tổng {result.pagination.total} phiếu · Trang {page}/
                {Math.max(
                  1,
                  Math.ceil(
                    result.pagination.total / result.pagination.page_size,
                  ),
                )}
              </span>
              <div className="flex gap-2">
                <button
                  className={docButton}
                  disabled={page === 1}
                  onClick={() => setPage((n) => n - 1)}
                >
                  Trang trước
                </button>
                <button
                  className={docButton}
                  disabled={
                    page * result.pagination.page_size >=
                    result.pagination.total
                  }
                  onClick={() => setPage((n) => n + 1)}
                >
                  Trang sau
                </button>
              </div>
            </div>
          </>
        )
      )}
      {form && (
        <DocumentEditor
          key={form.record?.id ?? "new"}
          kind={kind}
          record={form.record}
          api={api}
          documents={documents}
          canEdit={
            writable &&
            (!form.record ||
              user.role !== "warehouse" ||
              form.record.created_by === user.id)
          }
          onClose={() => setForm(undefined)}
          onSaved={(row) => {
            setForm(undefined);
            setNotice("Đã lưu nháp " + row.code + ". Chưa ghi sổ kho.");
            setRevision((n) => n + 1);
          }}
        />
      )}
      {history && (
        <DocumentHistory
          documents={documents}
          row={history}
          onClose={() => setHistory(undefined)}
        />
      )}
      {bulk && (
        <DocumentBulkImport
          documents={documents}
          onClose={() => setBulk(false)}
          onSaved={() => setRevision((n) => n + 1)}
        />
      )}
      {action && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-3">
          <section
            role="dialog"
            aria-modal="true"
            aria-label="Xử lý chứng từ"
            className="w-full max-w-lg space-y-3 rounded-xl bg-white p-5 text-slate-900"
          >
            <h3 className="font-bold">
              Xử lý <span className="font-mono">{action.row.code}</span>
            </h3>
            <p className="text-xs text-slate-600">
              {action.row.workflow_snapshot
                ? `Quy trình: ${action.row.workflow_snapshot.name} · bước ${Math.min(action.row.approval_step + 1, action.row.workflow_snapshot.steps.length)}/${action.row.workflow_snapshot.steps.length}`
                : "Phiếu chưa gửi duyệt."}
            </p>
            <label className="block text-xs font-semibold">
              Thao tác
              <select
                aria-label="Thao tác chứng từ"
                className={docInput + " mt-1"}
                value={action.kind}
                disabled={busy}
                onChange={(e) => setAction({ ...action, kind: e.target.value })}
              >
                <option value="">Chọn thao tác</option>
                {kind === "proposal" && editableDraft(action.row.status) && (
                  <option value="submit">Gửi duyệt đề xuất</option>
                )}
                {kind === "proposal" &&
                  action.row.status === "pending" &&
                  action.row.workflow_snapshot?.steps[
                    action.row.approval_step
                  ]?.approver_ids.includes(user.id) && (
                    <>
                      <option value="approve">Duyệt bước hiện tại</option>
                      <option value="return">Trả về để bổ sung</option>
                      <option value="reject">Từ chối</option>
                    </>
                  )}
                {admin &&
                  action.row.status === "approved" &&
                  kind === "proposal" && (
                    <option value="revoke">Bỏ duyệt</option>
                  )}
                {admin && <option value="cancel">Hủy phiếu</option>}
              </select>
            </label>
            <label className="block text-xs font-semibold">
              Lý do *
              <textarea
                className={docInput + " mt-1"}
                value={reason}
                disabled={busy}
                onChange={(e) => setReason(e.target.value)}
              />
            </label>
            <button
              className={docButton + " w-full"}
              disabled
              title="Chưa bật ghi sổ kho ở bản dựng này"
            >
              Ghi sổ / nhận đắp — chưa bật
            </button>
            <div>
              {error && (
                <p role="alert" className="text-xs text-red-700">
                  {error}
                </p>
              )}
            </div>
            <div className="flex justify-end gap-2">
              <button
                className={docButton}
                disabled={busy}
                onClick={() => setAction(undefined)}
              >
                Đóng
              </button>
              <button
                className={docButton + " !bg-blue-600 !text-white"}
                disabled={busy || !reason.trim() || !action.kind}
                onClick={async () => {
                  if (actionLock.current) return;
                  actionLock.current = true;
                  setBusy(true);
                  setError("");
                  try {
                    await documents.action(action.row, action.kind, reason);
                    setAction(undefined);
                    setNotice("Đã lưu thao tác và lịch sử.");
                    setRevision((n) => n + 1);
                  } catch (e) {
                    setError(accessMessage(e));
                  } finally {
                    setBusy(false);
                    actionLock.current = false;
                  }
                }}
              >
                {busy ? "Đang lưu…" : "Xác nhận"}
              </button>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}
