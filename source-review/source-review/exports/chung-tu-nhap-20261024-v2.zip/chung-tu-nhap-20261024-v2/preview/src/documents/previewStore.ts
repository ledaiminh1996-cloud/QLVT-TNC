import { foldDocumentSearch } from "../../shared/documentSearch";
/** Development-only, explicit in-memory preview. Never used as a fallback for an API failure. */
import { createCatalogClient, CatalogApiError } from "../api/catalogClient";
import type { CatalogRow, Resource, Session } from "../api/catalogClient";
import {
  documentKinds,
  emptyDraft,
  parseDraft,
  draftTotals,
  editableDraft,
} from "../../shared/documents";
import type {
  DocumentRecord,
  DocumentDraft,
  DocumentWorkflow,
  DocumentSummary,
} from "../../shared/documents";
import type { DocumentClient, DocumentEvent } from "./documentClient";
import { searchIncludes } from "../../shared/searchText";
const clone = <T>(value: T): T => structuredClone(value);
export function createDocumentPreview(
  user: () => NonNullable<Session["user"]>,
) {
  const fixtures: Partial<Record<Resource, CatalogRow[]>> = {
    parts: [
      {
        id: "part-filter",
        version: 1,
        sku: "M-IN-TDONG-0001",
        name: "Lọc dầu động cơ",
        unit: "Cái",
        unit_price_vnd: 150000,
        is_serialized: 0,
        is_active: 1,
      },
      {
        id: "part-tire",
        version: 1,
        sku: "M-RM-LOP-0001",
        name: "Lốp xe 12R22.5",
        unit: "Quả",
        unit_price_vnd: 8500000,
        is_serialized: 1,
        is_active: 1,
      },
      {
        id: "part-oil",
        version: 1,
        sku: "M-DC-TIEU-0020",
        name: "Dầu DO",
        is_fuel: 1,
        unit: "Lít",
        unit_price_vnd: 21500,
        is_serialized: 0,
        is_active: 1,
      },
      {
        id: "part-sim",
        version: 1,
        sku: "M-DC-SIM-0001",
        name: "SIM 4G định vị",
        needs_data_package: 1,
        unit: "Cái",
        unit_price_vnd: 50000,
        is_serialized: 1,
        is_active: 1,
      },
    ],
    warehouses: [
      {
        id: "wh-1",
        version: 1,
        code: "KHO01",
        name: "Kho trung tâm",
        kind: "parts",
        is_active: 1,
      },
      {
        id: "wh-2",
        version: 1,
        code: "KHO02",
        name: "Kho chi nhánh",
        kind: "parts",
        is_active: 1,
      },
    ],
    "fuel-tanks": [
      {
        id: "tank-1",
        version: 1,
        code: "BON01",
        name: "Bồn dầu số 1",
        warehouse_id: "wh-1",
        capacity_milli: 25000000,
        is_active: 1,
      },
    ],
    suppliers: [
      {
        id: "supplier-1",
        version: 1,
        code: "NCC00001",
        name: "Nhà cung cấp mẫu",
        is_active: 1,
      },
    ],
    departments: [
      {
        id: "dept-1",
        version: 1,
        code: "KHO",
        name: "Bộ phận kho",
        kind: "employee",
        is_active: 1,
      },
    ],
    vehicles: [
      {
        id: "vehicle-1",
        version: 1,
        plate_number: "50H-123.45",
        type: "tractor",
        brand_model: "Đầu kéo mẫu",
        status: "active",
      },
      {
        id: "trailer-1",
        version: 1,
        plate_number: "51R-456.78",
        type: "trailer",
        brand_model: "Rơ moóc mẫu",
        status: "active",
      },
    ],
    equipment: [
      {
        id: "generator-1",
        version: 1,
        code: "MP001",
        name: "Máy phát mẫu",
        type: "generator",
        status: "active",
      },
    ],
  };
  const catalog = createCatalogClient(async (input) => {
    const url = new URL(String(input), "http://preview.invalid"),
      resource = url.pathname.split("/").pop() as Resource,
      q = url.searchParams.get("q") ?? "",
      current = Number(url.searchParams.get("page") ?? 1),
      size = Number(url.searchParams.get("page_size") ?? 25);
    const all = (fixtures[resource] ?? []).filter(
      (row) =>
        searchIncludes(Object.values(row).join(" "), q) &&
        (!url.searchParams.get("warehouse_id") ||
          row.warehouse_id === url.searchParams.get("warehouse_id")),
    );
    return Response.json({
      data: clone(all.slice((current - 1) * size, current * size)),
      pagination: { page: current, page_size: size, total: all.length },
    });
  });
  const records = new Map<string, DocumentRecord>(),
    events = new Map<string, DocumentEvent[]>(),
    keys = new Map<string, { hash: string; id: string }>(),
    counters = new Map<string, number>();
  let workflows: DocumentWorkflow[] = [
    {
      id: "flow-1",
      version: 1,
      name: "Duyệt mẫu bộ phận kho",
      department_id: "dept-1",
      proposal_type: "purchase",
      is_active: 1,
      steps: [
        {
          label: "Quản trị duyệt",
          mode: "any",
          approver_ids: ["preview-admin"],
        },
      ],
    },
  ];
  function changed(): never {
    throw new CatalogApiError(
      409,
      "VERSION_CONFLICT",
      "Phiếu đã thay đổi. Tải lại để đối chiếu.",
    );
  }
  function labels(draft: DocumentDraft) {
    const result: Record<string, string> = {};
    for (const [resource, rows] of Object.entries(fixtures))
      for (const row of rows) {
        result[resource + ":" + row.id] =
          String(row.sku ?? row.plate_number ?? row.code) +
          " — " +
          String(row.name ?? row.brand_model ?? "");
        if (resource === "parts") {
          result["unit:" + row.id] = String(row.unit);
          result["sku:" + row.id] = String(row.sku);
          result["serialized:" + row.id] = String(row.is_serialized);
          result["fuel:" + row.id] = String(row.is_fuel ?? 0);
          result["data:" + row.id] = String(row.needs_data_package ?? 0);
        }
      }
    const wanted = new Set([
      "warehouses:" + draft.warehouse_id,
      "warehouses:" + draft.to_warehouse_id,
      "suppliers:" + draft.supplier_id,
      "departments:" + draft.department_id,
    ]);
    for (const line of draft.lines) {
      for (const prefix of [
        "parts:",
        "unit:",
        "sku:",
        "serialized:",
        "fuel:",
        "data:",
      ])
        wanted.add(prefix + line.part_id);
      wanted.add("fuel-tanks:" + line.tank_id);
      wanted.add(
        (line.target_type === "vehicle" ? "vehicles:" : "equipment:") +
          line.target_id,
      );
    }
    return Object.fromEntries(
      Object.entries(result).filter(([key]) => wanted.has(key)),
    );
  }
  function event(
    row: DocumentRecord,
    action: string,
    reason: string,
    before: DocumentRecord | null,
  ) {
    const previous = events.get(row.id) ?? [];
    events.set(row.id, [
      {
        id: crypto.randomUUID(),
        actor_name: user().display_name,
        action,
        reason,
        created_at: new Date().toISOString(),
        before_json: before ? JSON.stringify(before) : null,
        after_json: JSON.stringify(row),
      },
      ...previous,
    ]);
  }
  const client: DocumentClient = {
    async list(options) {
      options.signal?.throwIfAborted();
      const filtered = [...records.values()]
        .filter(
          (r) =>
            r.draft.kind === options.kind &&
            (!options.status || r.status === options.status) &&
            (!options.from || r.draft.business_at >= options.from) &&
            (!options.to || r.draft.business_at.slice(0, 10) <= options.to) &&
            foldDocumentSearch(
              r.code +
                " " +
                Object.values(r.labels).join(" ") +
                " " +
                r.draft.recipient +
                " " +
                r.draft.lines
                  .flatMap((l) => [l.serial, l.data_package, l.tank_id])
                  .join(" "),
            ).includes(foldDocumentSearch(options.q ?? "")),
        )
        .sort((a, b) => b.updated_at.localeCompare(a.updated_at));
      const current = options.page ?? 1;
      return {
        data: filtered.slice((current - 1) * 25, current * 25).map(
          (r) =>
            ({
              id: r.id,
              version: r.version,
              code: r.code,
              status: r.status,
              kind: r.draft.kind,
              business_at: r.draft.business_at,
              totals: clone(r.totals),
              created_by: r.created_by,
              created_by_name: r.created_by_name,
              created_at: r.created_at,
              updated_at: r.updated_at,
              line_count: r.draft.lines.length,
              warehouse_label:
                r.labels["warehouses:" + r.draft.warehouse_id] ?? "",
              partner_label:
                r.labels["suppliers:" + r.draft.supplier_id] ??
                r.draft.recipient,
            }) as DocumentSummary,
        ),
        pagination: { page: current, page_size: 25, total: filtered.length },
      };
    },
    async get(id, signal) {
      signal?.throwIfAborted();
      const r = records.get(id);
      if (!r)
        throw new CatalogApiError(
          400,
          "DOCUMENT_VALIDATION",
          "Không tìm thấy phiếu mẫu.",
        );
      return clone(r);
    },
    async save(input, key, old, reason) {
      const draft = parseDraft(input);
      const before = old ? records.get(old.id) : undefined;
      if (old && (!before || before.version !== old.version)) return changed();
      if (before && !editableDraft(before.status))
        throw new CatalogApiError(
          400,
          "DOCUMENT_VALIDATION",
          "Phiếu không ở trạng thái sửa được.",
        );
      for (const line of draft.lines) {
        const part = fixtures.parts?.find((p) => p.id === line.part_id);
        if (line.serial && part?.is_serialized !== 1)
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Vật tư không quản lý SERIAL, không nhập Serial.",
          );
        if (line.tank_id && part?.is_fuel !== 1)
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Vật tư không phải nhiên liệu.",
          );
        if (line.data_package && part?.needs_data_package !== 1)
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Vật tư không sử dụng gói Data.",
          );
        if (part?.is_serialized === 1 && !line.serial)
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Vật tư SERIAL cần Serial.",
          );
      }
      const hash = JSON.stringify(draft),
        found = keys.get(key);
      if (!old && found) {
        if (found.hash !== hash)
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Mã yêu cầu đã dùng cho nội dung khác.",
          );
        return clone(records.get(found.id)!);
      }
      if (
        before &&
        (!reason?.trim() ||
          before.draft.kind !== draft.kind ||
          before.draft.business_at.slice(0, 7) !==
            draft.business_at.slice(0, 7))
      )
        throw new CatalogApiError(
          400,
          "DOCUMENT_VALIDATION",
          "Cần lý do sửa; không đổi loại/tháng đã cấp số.",
        );
      const stamp = new Date().toISOString(),
        period = draft.business_at.slice(0, 7),
        counterKey = period + documentKinds[draft.kind].code,
        count = (counters.get(counterKey) ?? 0) + 1;
      const code =
        before?.code ??
        draft.business_at.slice(5, 7) +
          "." +
          draft.business_at.slice(2, 4) +
          "." +
          String(count).padStart(5, "0") +
          "/" +
          documentKinds[draft.kind].code +
          (draft.kind === "proposal" ? "/KHO" : "");
      const row: DocumentRecord = {
        id: before?.id ?? crypto.randomUUID(),
        version: (before?.version ?? 0) + 1,
        code,
        status: before?.status ?? "draft",
        draft: clone(draft),
        labels: labels(draft),
        totals: draftTotals(draft),
        created_by: before?.created_by ?? user().id,
        created_by_name: before?.created_by_name ?? user().display_name,
        created_at: before?.created_at ?? stamp,
        updated_at: stamp,
        workflow_snapshot: before?.workflow_snapshot ?? null,
        approval_step: before?.approval_step ?? 0,
        approval_votes: before?.approval_votes ?? [],
      };
      records.set(row.id, row);
      if (!before) {
        keys.set(key, { hash, id: row.id });
        counters.set(counterKey, count);
      }
      event(
        row,
        before ? "save" : "create",
        reason ?? "Lập nháp mẫu",
        before ?? null,
      );
      return clone(row);
    },
    async action(old, action, reason) {
      const before = records.get(old.id);
      if (!before || before.version !== old.version) return changed();
      if (!reason.trim())
        throw new CatalogApiError(400, "DOCUMENT_VALIDATION", "Cần lý do.");
      const row = clone(before);
      if (action === "submit") {
        const flow = workflows.find(
          (w) =>
            w.department_id === row.draft.department_id &&
            w.proposal_type === row.draft.proposal_type &&
            w.is_active === 1,
        );
        if (
          row.draft.kind !== "proposal" ||
          !editableDraft(row.status) ||
          !flow
        )
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Chưa có quy trình phù hợp.",
          );
        row.status = "pending";
        row.workflow_snapshot = { name: flow.name, steps: clone(flow.steps) };
        row.approval_step = 0;
        row.approval_votes = [];
      } else if (["approve", "return", "reject"].includes(action)) {
        const step = row.workflow_snapshot?.steps[row.approval_step];
        if (row.status !== "pending" || !step?.approver_ids.includes(user().id))
          throw new CatalogApiError(
            400,
            "DOCUMENT_VALIDATION",
            "Không thuộc bước duyệt hiện tại.",
          );
        if (action === "return") row.status = "returned";
        else if (action === "reject") row.status = "rejected";
        else {
          if (row.approval_votes.includes(user().id))
            throw new CatalogApiError(
              400,
              "DOCUMENT_VALIDATION",
              "Bạn đã duyệt.",
            );
          row.approval_votes.push(user().id);
          if (
            step.mode === "any" ||
            step.approver_ids.every((id) => row.approval_votes.includes(id))
          ) {
            row.approval_step++;
            row.approval_votes = [];
            if (row.approval_step === row.workflow_snapshot!.steps.length)
              row.status = "approved";
          }
        }
      } else if (action === "cancel") row.status = "cancelled";
      else if (action === "revoke") row.status = "returned";
      else
        throw new CatalogApiError(
          400,
          "DOCUMENT_VALIDATION",
          "Chưa bật ghi sổ trong bản dựng.",
        );
      row.version++;
      row.updated_at = new Date().toISOString();
      records.set(row.id, row);
      event(row, action, reason, before);
      return clone(row);
    },
    async history(id, page, signal) {
      signal?.throwIfAborted();
      const all = events.get(id) ?? [];
      return {
        data: clone(all.slice((page - 1) * 25, page * 25)),
        pagination: { page, page_size: 25, total: all.length },
      };
    },
    async workflows(signal) {
      signal?.throwIfAborted();
      return clone(workflows);
    },
    async approvers() {
      return [
        { id: "preview-admin", display_name: "Quản trị mẫu", role: "admin" },
        {
          id: "preview-accountant",
          display_name: "Kế toán mẫu",
          role: "accountant",
        },
      ];
    },
    async saveWorkflow(value, old) {
      const row = {
        ...clone(value),
        id: old?.id ?? crypto.randomUUID(),
        version: (old?.version ?? 0) + 1,
      };
      if (
        old &&
        workflows.find((w) => w.id === old.id)?.version !== old.version
      )
        return changed();
      workflows = old
        ? workflows.map((w) => (w.id === old.id ? row : w))
        : [...workflows, row];
      return clone(row);
    },
  };
  const draft = emptyDraft("receipt");
  draft.business_at = "2026-10-24T08:30";
  draft.warehouse_id = "wh-1";
  draft.supplier_id = "supplier-1";
  draft.lines[0].part_id = "part-filter";
  draft.lines[0].quantity = "2";
  draft.lines[0].document_quantity = "2";
  draft.lines[0].unit_price = "150000";
  draft.lines[0].vat_rate = "8";
  const ready = client.save(draft, "seed");
  return { catalog, documents: client, ready };
}
