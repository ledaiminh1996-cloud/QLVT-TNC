import {
  documentKinds,
  draftTotals,
  parseDraft,
  editableDraft,
  scaledDecimal,
} from "../../shared/documents.ts";
import type {
  DocumentDraft,
  DocumentRecord,
  DocumentWorkflow,
  ApprovalStep,
  DraftStatus,
} from "../../shared/documents.ts";
import {
  foldDocumentSearch,
  documentSearchPattern,
} from "../../shared/documentSearch.ts";
import type { Env, User, Row } from "./types.ts";
import { ApiError, json, readJson } from "./http.ts";
import { requireRole } from "./auth.ts";
const fail = (message: string): never => {
  throw new ApiError(400, "DOCUMENT_VALIDATION", message);
};
function parse(value: unknown) {
  try {
    return parseDraft(value);
  } catch (e) {
    return fail(e instanceof Error ? e.message : "Phiếu không hợp lệ.");
  }
}
const str = (value: unknown, max = 1000) => {
  if (typeof value !== "string" || !value.trim() || value.length > max)
    return fail("Thiếu nội dung hoặc nội dung quá dài.");
  return value.trim();
};
function version(value: unknown) {
  if (!Number.isSafeInteger(value) || Number(value) < 1)
    return fail("Thiếu phiên bản phiếu.");
  return Number(value);
}
function paging(url: URL) {
  const page = Number(url.searchParams.get("page") ?? 1),
    size = Number(url.searchParams.get("page_size") ?? 25);
  if (
    !Number.isSafeInteger(page) ||
    page < 1 ||
    !Number.isSafeInteger(size) ||
    size < 1 ||
    size > 100
  )
    return fail("Trang không hợp lệ.");
  return { page, size };
}
const own = (user: User) => user.role === "warehouse";
const approver = (row: Row, user: User) =>
  row.workflow_json &&
  JSON.parse(String(row.workflow_json)).steps.some((step: ApprovalStep) =>
    step.approver_ids.includes(user.id),
  );
async function rowFor(env: Env, id: string, user: User): Promise<Row> {
  const row = await env.DB.prepare(
    "SELECT d.*,u.display_name AS created_by_name FROM document_drafts d JOIN app_users u ON u.id=d.created_by WHERE d.id=?",
  )
    .bind(id)
    .first<Row>();
  if (!row) throw new ApiError(404, "NOT_FOUND", "Không tìm thấy phiếu.");
  if (own(user) && row.created_by !== user.id && !approver(row, user))
    throw new ApiError(403, "FORBIDDEN", "Chỉ được mở phiếu do mình lập.");
  return row;
}
async function detail(env: Env, row: Row): Promise<DocumentRecord> {
  const lines = await env.DB.prepare(
    "SELECT line_json FROM document_draft_lines WHERE document_id=? ORDER BY line_number",
  )
    .bind(row.id)
    .all<{ line_json: string }>();
  return {
    id: String(row.id),
    version: Number(row.version),
    code: String(row.code),
    status: row.status as DraftStatus,
    draft: {
      ...JSON.parse(String(row.header_json)),
      lines: lines.results.map((l) => JSON.parse(l.line_json)),
    } as DocumentDraft,
    labels: JSON.parse(String(row.labels_json)),
    totals: JSON.parse(String(row.totals_json)),
    created_by: String(row.created_by),
    created_by_name: String(row.created_by_name),
    created_at: String(row.created_at),
    updated_at: String(row.updated_at),
    workflow_snapshot: row.workflow_json
      ? JSON.parse(String(row.workflow_json))
      : null,
    approval_step: Number(row.approval_step),
    approval_votes: JSON.parse(String(row.approval_votes)),
  };
}
async function scope(env: Env, user: User, draft: DocumentDraft) {
  requireRole(user, ["admin", "accountant", "warehouse"]);
  if (own(user)) {
    for (const id of new Set(
      [draft.warehouse_id, draft.to_warehouse_id].filter(Boolean),
    )) {
      if (
        !(await env.DB.prepare(
          "SELECT 1 AS allowed FROM document_warehouse_access WHERE user_id=? AND warehouse_id=?",
        )
          .bind(user.id, id)
          .first())
      )
        throw new ApiError(
          403,
          "WAREHOUSE_SCOPE",
          "Kho chưa được cấp quyền lập chứng từ cho tài khoản.",
        );
    }
  }
}
async function references(
  env: Env,
  draft: DocumentDraft,
  previous?: DocumentRecord,
) {
  const labels: Record<string, string> = {};
  const old = previous?.draft;
  for (const [key, table] of [
    ["warehouse_id", "warehouses"],
    ["to_warehouse_id", "warehouses"],
    ["supplier_id", "suppliers"],
    ["department_id", "departments"],
  ] as const) {
    const id = draft[key];
    if (!id) continue;
    const row = await env.DB.prepare(`SELECT * FROM ${table} WHERE id=?`)
      .bind(id)
      .first<Row>();
    if (!row || (row.is_active !== 1 && old?.[key] !== id))
      return fail(
        "Chọn lại " +
          {
            warehouse_id: "Kho",
            to_warehouse_id: "Kho nhận",
            supplier_id: "Nhà cung cấp",
            department_id: "Bộ phận đề xuất",
          }[key] +
          " đang hoạt động.",
      );
    labels[table + ":" + id] = row.code + " — " + row.name;
    labels["code:" + table + ":" + id] = String(row.code);
  }
  const ids = [...new Set(draft.lines.map((l) => l.part_id))],
    parts = await env.DB.prepare(
      `SELECT * FROM parts WHERE id IN (${ids.map(() => "?").join(",")})`,
    )
      .bind(...ids)
      .all<Row>();
  const byId = new Map(parts.results.map((p) => [String(p.id), p]));
  for (const [index, line] of draft.lines.entries()) {
    try {
      const part = byId.get(line.part_id);
      if (
        !part ||
        (part.is_active !== 1 &&
          !old?.lines.some((l) => l.part_id === line.part_id))
      )
        return fail("Vật tư không tồn tại hoặc đã ngừng hoạt động.");
      labels["parts:" + part.id] = part.sku + " — " + part.name;
      labels["unit:" + part.id] = String(part.unit);
      labels["sku:" + part.id] = String(part.sku);
      labels["serialized:" + part.id] = String(part.is_serialized);
      labels["fuel:" + part.id] = String(part.is_fuel);
      labels["data:" + part.id] = String(part.needs_data_package);
      if (line.serial && part.is_serialized !== 1)
        return fail("Vật tư không quản lý SERIAL, không nhập Serial.");
      if (line.tank_id && part.is_fuel !== 1)
        return fail("Vật tư không phải nhiên liệu, không được chọn bồn.");
      if (line.data_package && part.needs_data_package !== 1)
        return fail("Vật tư không sử dụng gói Data.");
      if (part.is_serialized === 1 && !line.serial)
        return fail("Serial: bắt buộc đối với vật tư quản lý SERIAL.");
      if (
        part.is_serialized === 1 &&
        scaledDecimal(line.quantity, 3, "Số lượng") !== 1000n
      )
        return fail("Số lượng vật tư SERIAL phải bằng 1 mỗi dòng.");
      if (
        draft.kind === "retread" &&
        (part.is_serialized !== 1 ||
          part.category !== "tires" ||
          !line.serial ||
          scaledDecimal(line.quantity, 3, "Số lượng") !== 1000n)
      )
        return fail("Phiếu đắp vỏ chỉ nhận một vỏ SERIAL mỗi dòng.");
      const oil = part.is_fuel === 1;
      if (oil && draft.kind === "recovery")
        return fail("Dầu tiêu hao đã cấp dùng không được nhập thu hồi.");
      if (oil && ["receipt", "opening"].includes(draft.kind) && !line.tank_id)
        return fail("Dòng dầu DO cần chọn bồn nhập.");
      if (line.tank_id) {
        const tank = await env.DB.prepare("SELECT * FROM fuel_tanks WHERE id=?")
          .bind(line.tank_id)
          .first<Row>();
        if (
          !tank ||
          tank.warehouse_id !== draft.warehouse_id ||
          tank.is_active !== 1
        )
          return fail("Bồn dầu phải đang hoạt động và thuộc kho của phiếu.");
        labels["fuel-tanks:" + line.tank_id] = tank.code + " — " + tank.name;
      }
    } catch (error) {
      if (error instanceof ApiError)
        return fail("Dòng " + (index + 1) + ": " + error.message);
      throw error;
    }
  }
  for (const targetType of ["vehicle", "equipment"] as const) {
    const targetIds = [
      ...new Set(
        draft.lines
          .filter((l) => l.target_type === targetType && l.target_id)
          .map((l) => l.target_id),
      ),
    ];
    if (!targetIds.length) continue;
    const table = targetType === "vehicle" ? "vehicles" : "equipment";
    const rows = await env.DB.prepare(
      `SELECT * FROM ${table} WHERE id IN (${targetIds.map(() => "?").join(",")})`,
    )
      .bind(...targetIds)
      .all<Row>();
    for (const id of targetIds) {
      const row = rows.results.find((r) => r.id === id);
      if (
        !row ||
        (row.status !== "active" &&
          !old?.lines.some(
            (l) => l.target_type === targetType && l.target_id === id,
          ))
      )
        return fail(
          "Dòng " +
            (draft.lines.findIndex(
              (l) => l.target_type === targetType && l.target_id === id,
            ) +
              1) +
            ": Thiết bị nhận không tồn tại hoặc ngừng hoạt động.",
        );
      labels[table + ":" + id] =
        String(row.plate_number ?? row.code) +
        " — " +
        String(row.name ?? row.brand_model ?? "");
    }
  }
  return labels;
}
async function checkLock(env: Env, draft: DocumentDraft) {
  const period = await env.DB.prepare(
    "SELECT max(period) AS period FROM accounting_periods WHERE is_locked=1",
  ).first<{ period: string | null }>();
  if (period?.period && draft.business_at.slice(0, 7) <= period.period)
    throw new ApiError(409, "PERIOD_LOCKED", "Ngày chứng từ thuộc kỳ đã khóa.");
}
function searchText(
  draft: DocumentDraft,
  labels: Record<string, string>,
  code = "",
) {
  return foldDocumentSearch(
    [
      code,
      ...Object.values(labels),
      draft.recipient,
      draft.invoice_number,
      draft.notes,
      draft.purpose,
      ...draft.lines.flatMap((l) => [
        l.serial,
        l.tank_id,
        l.data_package,
        l.notes,
      ]),
    ].join(" "),
  );
}
function header(draft: DocumentDraft) {
  const { lines, ...fields } = draft;
  return JSON.stringify(fields);
}
function lines(env: Env, id: string, draft: DocumentDraft) {
  return draft.lines.map((line, index) =>
    env.DB.prepare(
      "INSERT INTO document_draft_lines(id,document_id,line_number,part_id,line_json) VALUES (?,?,?,?,?)",
    ).bind(line.id, id, index + 1, line.part_id, JSON.stringify(line)),
  );
}
function audit(
  env: Env,
  id: string,
  user: User,
  action: string,
  reason: string,
  before: unknown,
  after: unknown,
  requestId: string,
) {
  return env.DB.prepare(
    "INSERT INTO document_draft_events(id,document_id,actor_id,action,reason,before_json,after_json,request_id) VALUES (?,?,?,?,?,?,?,?)",
  ).bind(
    crypto.randomUUID(),
    id,
    user.id,
    action,
    reason,
    before ? JSON.stringify(before) : null,
    JSON.stringify(after),
    requestId,
  );
}
async function batch(env: Env, statements: D1PreparedStatement[]) {
  try {
    await env.DB.batch(statements);
  } catch (e) {
    if (
      /UNIQUE constraint failed: document_workflows.department_id, document_workflows.proposal_type/i.test(
        String(e),
      )
    )
      throw new ApiError(
        409,
        "WORKFLOW_EXISTS",
        "Đã có quy trình cho bộ phận và loại này",
      );
    if (/version>=1/.test(String(e)))
      throw new ApiError(
        409,
        "VERSION_CONFLICT",
        "Phiếu đã thay đổi. Tải lại để đối chiếu.",
      );
    throw e;
  }
}
export async function handleDocuments(
  request: Request,
  env: Env,
  user: User,
  id: string | undefined,
  requestId: string,
): Promise<Response> {
  const url = new URL(request.url);
  if (request.method === "GET") {
    if (id) {
      const row = await rowFor(env, id, user);
      if (url.searchParams.get("view") === "history") {
        const { page, size } = paging(url);
        const results = await env.DB.batch([
          env.DB.prepare(
            "SELECT e.*,u.display_name AS actor_name FROM document_draft_events e JOIN app_users u ON u.id=e.actor_id WHERE document_id=? ORDER BY e.created_at DESC,e.rowid DESC LIMIT ? OFFSET ?",
          ).bind(id, size, (page - 1) * size),
          env.DB.prepare(
            "SELECT count(*) AS total FROM document_draft_events WHERE document_id=?",
          ).bind(id),
        ]);
        return json({
          data: results[0].results,
          pagination: {
            page,
            page_size: size,
            total: (results[1].results[0] as { total: number }).total,
          },
        });
      }
      return json({ data: await detail(env, row) });
    }
    const { page, size } = paging(url),
      kind = url.searchParams.get("kind") ?? "receipt",
      status = url.searchParams.get("status") ?? "",
      q = url.searchParams.get("q") ?? "",
      from = url.searchParams.get("from") ?? "",
      to = url.searchParams.get("to") ?? "";
    if (
      !Object.hasOwn(documentKinds, kind) ||
      ![
        "",
        "draft",
        "pending",
        "approved",
        "returned",
        "rejected",
        "cancelled",
      ].includes(status) ||
      q.length > 200 ||
      [from, to].some((v) => v && !/^\d{4}-\d{2}-\d{2}$/.test(v))
    )
      return fail("Bộ lọc không hợp lệ.");

    const where =
      "d.kind=? AND (?='' OR d.status=?) AND (?='' OR d.search_text LIKE ? ESCAPE '\\') AND (?='' OR d.business_at>=?) AND (?='' OR d.business_at<?)" +
      (own(user)
        ? " AND (d.created_by=? OR EXISTS(SELECT 1 FROM json_each(d.workflow_json,'$.steps') step,json_each(step.value,'$.approver_ids') voter WHERE voter.value=?))"
        : "");
    const args: unknown[] = [
      kind,
      status,
      status,
      q,
      documentSearchPattern(q),
      from,
      from,
      to,
      to + "T23:59:59",
    ];
    if (own(user)) args.push(user.id, user.id);
    const selected =
      "d.id,d.version,d.code,d.kind,d.business_at,d.status,d.totals_json,d.created_by,d.created_at,d.updated_at,u.display_name AS created_by_name,(SELECT count(*) FROM document_draft_lines l WHERE l.document_id=d.id) AS line_count,d.labels_json,d.header_json";
    const results = await env.DB.batch([
      env.DB.prepare(
        `SELECT ${selected} FROM document_drafts d JOIN app_users u ON u.id=d.created_by WHERE ${where} ORDER BY d.business_at DESC,d.id LIMIT ? OFFSET ?`,
      ).bind(...args, size, (page - 1) * size),
      env.DB.prepare(
        `SELECT count(*) AS total FROM document_drafts d WHERE ${where}`,
      ).bind(...args),
    ]);
    const rows = results[0].results.map((raw) => {
      const r = raw as Row,
        labels = JSON.parse(String(r.labels_json)),
        head = JSON.parse(String(r.header_json)),
        { labels_json, header_json, totals_json, ...rest } = r;
      return {
        ...rest,
        totals: JSON.parse(String(totals_json)),
        warehouse_label: labels["warehouses:" + head.warehouse_id] ?? "",
        partner_label:
          labels["suppliers:" + head.supplier_id] ?? head.recipient,
      };
    });
    return json({
      data: rows,
      pagination: {
        page,
        page_size: size,
        total: (results[1].results[0] as { total: number }).total,
      },
    });
  }
  if (request.method === "POST" && !id) {
    const body = await readJson(request, 256 * 1024);
    if (
      Object.keys(body).some((k) => !["draft", "idempotency_key"].includes(k))
    )
      return fail("Trường yêu cầu không hợp lệ.");
    const key = str(body.idempotency_key, 128),
      draft = parse(body.draft);
    await scope(env, user, draft);
    const bytes = await crypto.subtle.digest(
        "SHA-256",
        new TextEncoder().encode(JSON.stringify(draft)),
      ),
      hash = Array.from(new Uint8Array(bytes), (b) =>
        b.toString(16).padStart(2, "0"),
      ).join("");
    const existing = await env.DB.prepare(
      "SELECT id,create_hash,created_by FROM document_drafts WHERE create_key=?",
    )
      .bind(key)
      .first<Row>();
    if (existing) {
      if (existing.create_hash !== hash || existing.created_by !== user.id)
        throw new ApiError(
          409,
          "IDEMPOTENCY_CONFLICT",
          "Mã yêu cầu đã dùng cho nội dung khác.",
        );
      return json({
        data: await detail(env, await rowFor(env, String(existing.id), user)),
      });
    }
    await checkLock(env, draft);
    const labels = await references(env, draft),
      id = crypto.randomUUID(),
      period = draft.business_at.slice(0, 7),
      symbol = documentKinds[draft.kind].code;
    const suffix =
      draft.kind === "proposal"
        ? "/" + (labels["code:departments:" + draft.department_id] ?? "")
        : "";
    const search = searchText(draft, labels);
    const statements = [
      env.DB.prepare(
        "INSERT INTO document_counters(period,kind,last_no) VALUES (?,?,1) ON CONFLICT(period,kind) DO UPDATE SET last_no=last_no+1",
      ).bind(period, symbol),
      env.DB.prepare(
        "INSERT INTO document_drafts(id,code,kind,business_at,warehouse_id,to_warehouse_id,supplier_id,department_id,header_json,labels_json,totals_json,search_text,created_by,create_key,create_hash) SELECT ?,printf('%s.%s.%05d/%s',?,?,last_no,?)||?,?,?,?,?,?,?,?,?,?,?,?,?,? FROM document_counters WHERE period=? AND kind=?",
      ).bind(
        id,
        draft.business_at.slice(5, 7),
        draft.business_at.slice(2, 4),
        symbol,
        suffix,
        draft.kind,
        draft.business_at,
        draft.warehouse_id || null,
        draft.to_warehouse_id || null,
        draft.supplier_id || null,
        draft.department_id || null,
        header(draft),
        JSON.stringify(labels),
        JSON.stringify(draftTotals(draft)),
        search,
        user.id,
        key,
        hash,
        period,
        symbol,
      ),
      env.DB.prepare(
        "UPDATE document_drafts SET search_text=search_text||' '||lower(replace(code,'Đ','d')) WHERE id=?",
      ).bind(id),
      ...lines(env, id, draft),
      audit(
        env,
        id,
        user,
        "create",
        "Lập nháp",
        null,
        { draft, labels, status: "draft" },
        requestId,
      ),
    ];
    try {
      await batch(env, statements);
    } catch (e) {
      const retry = await env.DB.prepare(
        "SELECT * FROM document_drafts WHERE create_key=?",
      )
        .bind(key)
        .first<Row>();
      if (retry && retry.create_hash === hash && retry.created_by === user.id)
        return json({
          data: await detail(env, await rowFor(env, String(retry.id), user)),
        });
      throw e;
    }
    return json({ data: await detail(env, await rowFor(env, id, user)) }, 201);
  }
  if (request.method === "PATCH" && id) {
    const body = await readJson(request, 256 * 1024);
    if (
      Object.keys(body).some(
        (k) => !["version", "action", "reason", "draft"].includes(k),
      )
    )
      return fail("Trường yêu cầu không hợp lệ.");
    const expected = version(body.version),
      reason = str(body.reason),
      action = str(body.action, 32),
      row = await rowFor(env, id, user),
      before = await detail(env, row);
    if (before.version !== expected)
      throw new ApiError(
        409,
        "VERSION_CONFLICT",
        "Phiếu đã thay đổi. Tải lại để đối chiếu.",
      );
    if (["post", "receive", "resume"].includes(action))
      throw new ApiError(
        409,
        "POSTING_NOT_ENABLED",
        "Bước này chỉ chuẩn bị chứng từ; chưa bật ghi sổ kho.",
      );
    await checkLock(env, before.draft);
    if (action === "save") {
      if (!editableDraft(before.status))
        throw new ApiError(
          409,
          "INVALID_STATE",
          "Chỉ sửa phiếu Nháp hoặc Trả về.",
        );
      const draft = parse(body.draft);
      if (
        draft.kind !== before.draft.kind ||
        draft.business_at.slice(0, 7) !== before.draft.business_at.slice(0, 7)
      )
        return fail("Không đổi loại hoặc tháng sau khi đã cấp số.");
      await scope(env, user, draft);
      await checkLock(env, draft);
      const labels = await references(env, draft, before);
      await batch(env, [
        env.DB.prepare(
          "UPDATE document_drafts SET version=CASE WHEN version=? THEN version+1 ELSE -1 END,business_at=?,warehouse_id=?,to_warehouse_id=?,supplier_id=?,department_id=?,header_json=?,labels_json=?,totals_json=?,search_text=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
        ).bind(
          expected,
          draft.business_at,
          draft.warehouse_id || null,
          draft.to_warehouse_id || null,
          draft.supplier_id || null,
          draft.department_id || null,
          header(draft),
          JSON.stringify(labels),
          JSON.stringify(draftTotals(draft)),
          searchText(draft, labels, before.code),
          id,
        ),
        env.DB.prepare(
          "DELETE FROM document_draft_lines WHERE document_id=?",
        ).bind(id),
        ...lines(env, id, draft),
        audit(
          env,
          id,
          user,
          action,
          reason,
          before,
          { draft, labels, status: before.status },
          requestId,
        ),
      ]);
    } else {
      let status = before.status,
        snapshot = before.workflow_snapshot,
        step = before.approval_step,
        votes = [...before.approval_votes];
      if (action === "cancel") {
        requireRole(user, ["admin", "accountant"]);
        if (status === "cancelled")
          throw new ApiError(409, "INVALID_STATE", "Phiếu đã hủy.");
        status = "cancelled";
      } else if (action === "submit") {
        await scope(env, user, before.draft);
        if (before.draft.kind !== "proposal" || !editableDraft(status))
          throw new ApiError(
            409,
            "INVALID_STATE",
            "Chỉ gửi đề xuất Nháp hoặc Trả về.",
          );
        const workflow = await env.DB.prepare(
          "SELECT * FROM document_workflows WHERE department_id=? AND proposal_type=? AND is_active=1",
        )
          .bind(before.draft.department_id, before.draft.proposal_type)
          .first<Row>();
        if (!workflow)
          throw new ApiError(
            409,
            "WORKFLOW_REQUIRED",
            "Chưa có quy trình duyệt cho bộ phận và loại đề xuất.",
          );
        snapshot = {
          name: String(workflow.name),
          steps: JSON.parse(String(workflow.steps_json)),
        };
        status = "pending";
        step = 0;
        votes = [];
      } else if (action === "revoke") {
        requireRole(user, ["admin", "accountant"]);
        if (status !== "approved")
          throw new ApiError(
            409,
            "INVALID_STATE",
            "Phiếu chưa được duyệt xong.",
          );
        status = "returned";
      } else if (["approve", "return", "reject"].includes(action)) {
        if (
          status !== "pending" ||
          !snapshot?.steps[step]?.approver_ids.includes(user.id)
        )
          throw new ApiError(
            403,
            "APPROVAL_SCOPE",
            "Không thuộc bước duyệt hiện tại.",
          );
        if (action === "return") status = "returned";
        else if (action === "reject") status = "rejected";
        else {
          if (votes.includes(user.id))
            throw new ApiError(
              409,
              "ALREADY_APPROVED",
              "Bạn đã duyệt bước này.",
            );
          votes.push(user.id);
          const current = snapshot.steps[step];
          if (
            current.mode === "any" ||
            current.approver_ids.every((id) => votes.includes(id))
          ) {
            step++;
            votes = [];
            if (step >= snapshot.steps.length) status = "approved";
          }
        }
      } else return fail("Thao tác không được hỗ trợ.");
      await batch(env, [
        env.DB.prepare(
          "UPDATE document_drafts SET version=CASE WHEN version=? THEN version+1 ELSE -1 END,status=?,workflow_json=?,approval_step=?,approval_votes=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?",
        ).bind(
          expected,
          status,
          snapshot ? JSON.stringify(snapshot) : null,
          step,
          JSON.stringify(votes),
          id,
        ),
        audit(
          env,
          id,
          user,
          action,
          reason,
          before,
          {
            draft: before.draft,
            labels: before.labels,
            status,
            snapshot,
            step,
            votes,
          },
          requestId,
        ),
      ]);
    }
    return json({ data: await detail(env, await rowFor(env, id, user)) });
  }
  throw new ApiError(405, "METHOD_NOT_ALLOWED", "Thao tác không được hỗ trợ.");
}
export async function handleDocumentWorkflows(
  request: Request,
  env: Env,
  user: User,
  id: string | undefined,
  requestId: string,
): Promise<Response> {
  if (request.method === "GET") {
    if (new URL(request.url).searchParams.get("view") === "approvers") {
      requireRole(user, ["admin", "accountant"]);
      const users = await env.DB.prepare(
        "SELECT id,display_name,role FROM app_users WHERE is_active=1 ORDER BY display_name",
      ).all();
      return json({ data: users.results });
    }
    const rows = await env.DB.prepare(
      "SELECT * FROM document_workflows ORDER BY name,id LIMIT 200",
    ).all<Row>();
    return json({
      data: rows.results.map((row) => ({
        ...row,
        steps: JSON.parse(String(row.steps_json)),
        steps_json: undefined,
      })),
    });
  }
  if (
    !((request.method === "POST" && !id) || (request.method === "PATCH" && id))
  )
    throw new ApiError(
      405,
      "METHOD_NOT_ALLOWED",
      "Thao tác không được hỗ trợ.",
    );
  requireRole(user, ["admin"]);
  const body = await readJson(request);
  if (
    Object.keys(body).some(
      (k) =>
        ![
          "version",
          "name",
          "department_id",
          "proposal_type",
          "steps",
          "is_active",
        ].includes(k),
    )
  )
    return fail("Cấu hình có trường không hợp lệ.");
  const name = str(body.name, 256),
    department = str(body.department_id, 128),
    kind = str(body.proposal_type, 32);
  if (
    !["purchase", "issue", "transfer", "repair"].includes(kind) ||
    typeof body.is_active !== "number" ||
    ![0, 1].includes(body.is_active)
  )
    return fail("Cấu hình không hợp lệ.");
  if (
    !(await env.DB.prepare(
      "SELECT id FROM departments WHERE id=? AND is_active=1",
    )
      .bind(department)
      .first())
  )
    return fail("Bộ phận không hoạt động.");
  if (
    !Array.isArray(body.steps) ||
    body.steps.length < 1 ||
    body.steps.length > 10
  )
    return fail("Quy trình cần 1–10 bước.");
  const steps: ApprovalStep[] = [];
  for (const raw of body.steps) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw))
      return fail("Bước duyệt không hợp lệ.");
    const s = raw as Record<string, unknown>;
    if (
      Object.keys(s).some(
        (k) => !["label", "mode", "approver_ids"].includes(k),
      ) ||
      !["any", "all"].includes(String(s.mode)) ||
      !Array.isArray(s.approver_ids) ||
      s.approver_ids.length < 1 ||
      s.approver_ids.length > 20
    )
      return fail("Bước duyệt cần người được phân công.");
    const ids = [...new Set(s.approver_ids.map((value) => str(value, 128)))];
    for (const userId of ids)
      if (
        !(await env.DB.prepare(
          "SELECT id FROM app_users WHERE id=? AND is_active=1 AND role!='viewer'",
        )
          .bind(userId)
          .first())
      )
        return fail("Người duyệt không hợp lệ.");
    steps.push({
      label: str(s.label, 256),
      mode: s.mode as "any" | "all",
      approver_ids: ids,
    });
  }
  const previous = id
    ? await env.DB.prepare("SELECT * FROM document_workflows WHERE id=?")
        .bind(id)
        .first<Row>()
    : null;
  if (id && !previous)
    throw new ApiError(404, "NOT_FOUND", "Không tìm thấy quy trình.");
  const key = id ?? crypto.randomUUID();
  let statement: D1PreparedStatement;
  if (id) {
    statement = env.DB.prepare(
      "UPDATE document_workflows SET version=CASE WHEN version=? THEN version+1 ELSE -1 END,name=?,department_id=?,proposal_type=?,steps_json=?,is_active=? WHERE id=?",
    ).bind(
      version(body.version),
      name,
      department,
      kind,
      JSON.stringify(steps),
      body.is_active,
      key,
    );
  } else
    statement = env.DB.prepare(
      "INSERT INTO document_workflows(id,name,department_id,proposal_type,steps_json,is_active) VALUES (?,?,?,?,?,?)",
    ).bind(key, name, department, kind, JSON.stringify(steps), body.is_active);
  await batch(env, [
    statement,
    env.DB.prepare(
      "INSERT INTO audit_events(id,actor_id,action,entity_type,entity_id,before_json,after_json,reason,request_id) VALUES (?,?,?,?,?,?,?,?,?)",
    ).bind(
      crypto.randomUUID(),
      user.id,
      id ? "update" : "create",
      "document_workflow",
      key,
      previous ? JSON.stringify(previous) : null,
      JSON.stringify({
        name,
        department,
        kind,
        steps,
        is_active: body.is_active,
      }),
      "Cấu hình quy trình duyệt",
      requestId,
    ),
  ]);
  return json(
    {
      data: {
        id: key,
        version: previous ? Number(previous.version) + 1 : 1,
        name,
        department_id: department,
        proposal_type: kind,
        steps,
        is_active: body.is_active,
      } as DocumentWorkflow,
    },
    id ? 200 : 201,
  );
}
